import { useState, useEffect, useCallback, useRef } from 'react';

interface HistoryEntry {
  id: number;
  expression: string;
  result: string;
  timestamp: number;
}

function App() {
  const [display, setDisplay] = useState('0');
  const [previousValue, setPreviousValue] = useState<string | null>(null);
  const [operator, setOperator] = useState<string | null>(null);
  const [waitingForOperand, setWaitingForOperand] = useState(false);
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [darkMode, setDarkMode] = useState(true);
  const [showHistory, setShowHistory] = useState(false);
  const [expression, setExpression] = useState('');
  const historyRef = useRef<HTMLDivElement>(null);

  // Load history from localStorage
  useEffect(() => {
    const savedHistory = localStorage.getItem('calculator-history');
    if (savedHistory) {
      try {
        setHistory(JSON.parse(savedHistory));
      } catch {
        setHistory([]);
      }
    }
    const savedTheme = localStorage.getItem('calculator-theme');
    if (savedTheme) {
      setDarkMode(savedTheme === 'dark');
    }
  }, []);

  // Save history to localStorage
  useEffect(() => {
    localStorage.setItem('calculator-history', JSON.stringify(history));
  }, [history]);

  // Save theme preference
  useEffect(() => {
    localStorage.setItem('calculator-theme', darkMode ? 'dark' : 'light');
  }, [darkMode]);

  const formatNumber = (num: number): string => {
    if (isNaN(num) || !isFinite(num)) return 'Error';
    const str = num.toString();
    if (str.length > 12) {
      if (Math.abs(num) >= 1e12 || (Math.abs(num) < 1e-6 && num !== 0)) {
        return num.toExponential(6);
      }
      return parseFloat(num.toPrecision(10)).toString();
    }
    return str;
  };

  const calculate = (left: number, right: number, op: string): number => {
    switch (op) {
      case '+': return left + right;
      case '-': return left - right;
      case '×': return left * right;
      case '÷': return right === 0 ? NaN : left / right;
      default: return right;
    }
  };

  const addToHistory = (expr: string, result: string) => {
    const entry: HistoryEntry = {
      id: Date.now(),
      expression: expr,
      result,
      timestamp: Date.now(),
    };
    setHistory(prev => [entry, ...prev].slice(0, 50));
  };

  const handleNumber = useCallback((num: string) => {
    if (waitingForOperand) {
      setDisplay(num);
      setWaitingForOperand(false);
    } else {
      if (display === '0' && num !== '.') {
        setDisplay(num);
      } else if (num === '.' && display.includes('.')) {
        return;
      } else if (display.length < 15) {
        setDisplay(display + num);
      }
    }
  }, [display, waitingForOperand]);

  const handleOperator = useCallback((nextOperator: string) => {
    const inputValue = parseFloat(display);

    if (previousValue !== null && operator && !waitingForOperand) {
      const result = calculate(parseFloat(previousValue), inputValue, operator);
      const formatted = formatNumber(result);
      if (formatted === 'Error') {
        setDisplay('Error');
        setPreviousValue(null);
        setOperator(null);
        setExpression('');
        setWaitingForOperand(true);
        return;
      }
      setDisplay(formatted);
      setPreviousValue(formatted);
      setExpression(`${formatted} ${nextOperator}`);
    } else {
      setPreviousValue(display);
      setExpression(`${display} ${nextOperator}`);
    }

    setOperator(nextOperator);
    setWaitingForOperand(true);
  }, [display, previousValue, operator, waitingForOperand]);

  const handleEquals = useCallback(() => {
    if (previousValue === null || operator === null) return;

    const inputValue = parseFloat(display);
    const prevValue = parseFloat(previousValue);
    const result = calculate(prevValue, inputValue, operator);
    const formatted = formatNumber(result);

    const expr = `${previousValue} ${operator} ${display}`;

    if (formatted === 'Error') {
      setDisplay('Error');
      addToHistory(expr, 'Error');
    } else {
      setDisplay(formatted);
      addToHistory(expr, formatted);
    }

    setPreviousValue(null);
    setOperator(null);
    setWaitingForOperand(true);
    setExpression('');
  }, [display, previousValue, operator]);

  const handleClear = useCallback(() => {
    setDisplay('0');
    setPreviousValue(null);
    setOperator(null);
    setWaitingForOperand(false);
    setExpression('');
  }, []);

  const handleDelete = useCallback(() => {
    if (waitingForOperand || display === 'Error') {
      setDisplay('0');
      setWaitingForOperand(false);
      return;
    }
    if (display.length === 1 || (display.length === 2 && display.startsWith('-'))) {
      setDisplay('0');
    } else {
      setDisplay(display.slice(0, -1));
    }
  }, [display, waitingForOperand]);

  const handlePercent = useCallback(() => {
    const value = parseFloat(display);
    if (isNaN(value)) return;

    let result: number;
    if (previousValue !== null && operator) {
      // Calculate percentage of previous value
      result = (parseFloat(previousValue) * value) / 100;
    } else {
      result = value / 100;
    }

    const formatted = formatNumber(result);
    setDisplay(formatted);
    setWaitingForOperand(false);
  }, [display, previousValue, operator]);

  const handleToggleSign = useCallback(() => {
    if (display === '0' || display === 'Error') return;
    if (display.startsWith('-')) {
      setDisplay(display.slice(1));
    } else {
      setDisplay('-' + display);
    }
  }, [display]);

  const clearHistory = () => {
    setHistory([]);
    localStorage.removeItem('calculator-history');
  };

  const loadFromHistory = (entry: HistoryEntry) => {
    setDisplay(entry.result);
    setPreviousValue(null);
    setOperator(null);
    setWaitingForOperand(true);
    setExpression('');
    setShowHistory(false);
  };

  // Keyboard support
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key >= '0' && e.key <= '9') {
        e.preventDefault();
        handleNumber(e.key);
      } else if (e.key === '.') {
        e.preventDefault();
        handleNumber('.');
      } else if (e.key === '+') {
        e.preventDefault();
        handleOperator('+');
      } else if (e.key === '-') {
        e.preventDefault();
        handleOperator('-');
      } else if (e.key === '*') {
        e.preventDefault();
        handleOperator('×');
      } else if (e.key === '/') {
        e.preventDefault();
        handleOperator('÷');
      } else if (e.key === 'Enter' || e.key === '=') {
        e.preventDefault();
        handleEquals();
      } else if (e.key === 'Escape') {
        e.preventDefault();
        handleClear();
      } else if (e.key === 'Backspace') {
        e.preventDefault();
        handleDelete();
      } else if (e.key === '%') {
        e.preventDefault();
        handlePercent();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleNumber, handleOperator, handleEquals, handleClear, handleDelete, handlePercent]);

  const getDisplayFontSize = () => {
    if (display.length > 12) return 'text-2xl';
    if (display.length > 9) return 'text-3xl';
    if (display.length > 7) return 'text-4xl';
    return 'text-5xl';
  };

  return (
    <div className={`min-h-screen transition-colors duration-300 ${darkMode ? 'bg-gradient-to-br from-gray-900 via-slate-900 to-gray-900' : 'bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50'}`}>
      <div className="max-w-md mx-auto px-4 py-4 min-h-screen flex flex-col">
        {/* Header */}
        <header className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <span className="text-2xl">🧮</span>
            <h1 className={`text-xl font-bold ${darkMode ? 'text-white' : 'text-gray-800'}`}>
              Smart Calculator
            </h1>
          </div>
          <div className="flex items-center gap-2">
            {/* History Toggle */}
            <button
              onClick={() => setShowHistory(!showHistory)}
              className={`p-2 rounded-xl transition-all duration-200 active:scale-95 ${
                darkMode
                  ? 'bg-gray-800 hover:bg-gray-700 text-gray-300'
                  : 'bg-white hover:bg-gray-100 text-gray-600 shadow-sm'
              }`}
              aria-label="Toggle history"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </button>
            {/* Theme Toggle */}
            <button
              onClick={() => setDarkMode(!darkMode)}
              className={`p-2 rounded-xl transition-all duration-200 active:scale-95 ${
                darkMode
                  ? 'bg-gray-800 hover:bg-gray-700 text-yellow-400'
                  : 'bg-white hover:bg-gray-100 text-indigo-600 shadow-sm'
              }`}
              aria-label="Toggle theme"
            >
              {darkMode ? (
                <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" />
                </svg>
              ) : (
                <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
                </svg>
              )}
            </button>
          </div>
        </header>

        {/* History Panel */}
        {showHistory && (
          <div className={`rounded-2xl mb-4 overflow-hidden transition-all duration-300 ${
            darkMode ? 'bg-gray-800/90 backdrop-blur-sm' : 'bg-white/90 backdrop-blur-sm shadow-lg'
          }`}>
            <div className="flex items-center justify-between p-3 border-b border-gray-500/20">
              <h2 className={`font-semibold text-sm ${darkMode ? 'text-gray-200' : 'text-gray-700'}`}>
                Calculation History
              </h2>
              {history.length > 0 && (
                <button
                  onClick={clearHistory}
                  className="text-xs px-3 py-1 rounded-lg bg-red-500/10 text-red-500 hover:bg-red-500/20 transition-colors active:scale-95"
                >
                  Clear All
                </button>
              )}
            </div>
            <div ref={historyRef} className="max-h-60 overflow-y-auto p-2">
              {history.length === 0 ? (
                <p className={`text-center py-6 text-sm ${darkMode ? 'text-gray-500' : 'text-gray-400'}`}>
                  No calculations yet
                </p>
              ) : (
                history.map((entry) => (
                  <button
                    key={entry.id}
                    onClick={() => loadFromHistory(entry)}
                    className={`w-full text-right p-3 rounded-xl mb-1 transition-all duration-150 active:scale-[0.98] ${
                      darkMode ? 'hover:bg-gray-700/50' : 'hover:bg-gray-50'
                    }`}
                  >
                    <div className={`text-xs ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                      {entry.expression}
                    </div>
                    <div className={`text-lg font-semibold ${darkMode ? 'text-white' : 'text-gray-800'}`}>
                      = {entry.result}
                    </div>
                  </button>
                ))
              )}
            </div>
          </div>
        )}

        {/* Calculator Body */}
        <div className="flex-1 flex flex-col">
          {/* Display */}
          <div className={`rounded-2xl p-5 mb-4 ${
            darkMode
              ? 'bg-gray-800/80 backdrop-blur-sm'
              : 'bg-white/80 backdrop-blur-sm shadow-lg'
          }`}>
            <div className={`text-right text-sm min-h-[20px] mb-1 ${
              darkMode ? 'text-gray-400' : 'text-gray-500'
            }`}>
              {expression}
            </div>
            <div className={`text-right font-bold transition-all duration-200 ${getDisplayFontSize()} ${
              display === 'Error'
                ? 'text-red-500'
                : darkMode ? 'text-white' : 'text-gray-800'
            }`}>
              {display}
            </div>
          </div>

          {/* Button Grid */}
          <div className="grid grid-cols-4 gap-3 flex-1">
            {/* Row 1: AC, +/−, %, ÷ */}
            <CalcButton
              label="AC"
              onClick={handleClear}
              variant="function"
              darkMode={darkMode}
            />
            <CalcButton
              label="+/−"
              onClick={handleToggleSign}
              variant="function"
              darkMode={darkMode}
            />
            <CalcButton
              label="%"
              onClick={handlePercent}
              variant="function"
              darkMode={darkMode}
            />
            <CalcButton
              label="÷"
              onClick={() => handleOperator('÷')}
              variant="operator"
              darkMode={darkMode}
              active={operator === '÷' && waitingForOperand}
            />

            {/* Row 2: 7, 8, 9, × */}
            <CalcButton label="7" onClick={() => handleNumber('7')} darkMode={darkMode} />
            <CalcButton label="8" onClick={() => handleNumber('8')} darkMode={darkMode} />
            <CalcButton label="9" onClick={() => handleNumber('9')} darkMode={darkMode} />
            <CalcButton
              label="×"
              onClick={() => handleOperator('×')}
              variant="operator"
              darkMode={darkMode}
              active={operator === '×' && waitingForOperand}
            />

            {/* Row 3: 4, 5, 6, − */}
            <CalcButton label="4" onClick={() => handleNumber('4')} darkMode={darkMode} />
            <CalcButton label="5" onClick={() => handleNumber('5')} darkMode={darkMode} />
            <CalcButton label="6" onClick={() => handleNumber('6')} darkMode={darkMode} />
            <CalcButton
              label="−"
              onClick={() => handleOperator('-')}
              variant="operator"
              darkMode={darkMode}
              active={operator === '-' && waitingForOperand}
            />

            {/* Row 4: 1, 2, 3, + */}
            <CalcButton label="1" onClick={() => handleNumber('1')} darkMode={darkMode} />
            <CalcButton label="2" onClick={() => handleNumber('2')} darkMode={darkMode} />
            <CalcButton label="3" onClick={() => handleNumber('3')} darkMode={darkMode} />
            <CalcButton
              label="+"
              onClick={() => handleOperator('+')}
              variant="operator"
              darkMode={darkMode}
              active={operator === '+' && waitingForOperand}
            />

            {/* Row 5: ⌫, 0, ., = */}
            <CalcButton
              label="⌫"
              onClick={handleDelete}
              variant="function"
              darkMode={darkMode}
            />
            <CalcButton label="0" onClick={() => handleNumber('0')} darkMode={darkMode} />
            <CalcButton label="." onClick={() => handleNumber('.')} darkMode={darkMode} />
            <CalcButton
              label="="
              onClick={handleEquals}
              variant="equals"
              darkMode={darkMode}
            />
          </div>

          {/* Footer */}
          <footer className={`text-center py-3 mt-4 text-xs ${
            darkMode ? 'text-gray-500' : 'text-gray-400'
          }`}>
            Powered by Muhaddis Iqbal
          </footer>
        </div>
      </div>
    </div>
  );
}

interface CalcButtonProps {
  label: string;
  onClick: () => void;
  variant?: 'number' | 'operator' | 'function' | 'equals';
  darkMode: boolean;
  active?: boolean;
}

function CalcButton({ label, onClick, variant = 'number', darkMode, active = false }: CalcButtonProps) {
  const getButtonStyles = () => {
    const base = 'rounded-2xl font-semibold text-xl transition-all duration-150 active:scale-95 active:brightness-90 flex items-center justify-center select-none h-16 sm:h-[72px]';

    if (variant === 'operator') {
      if (active) {
        return `${base} ${darkMode ? 'bg-indigo-400 text-white shadow-lg shadow-indigo-500/30' : 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/30'}`;
      }
      return `${base} ${darkMode ? 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-500/20' : 'bg-indigo-500 hover:bg-indigo-600 text-white shadow-md shadow-indigo-500/20'}`;
    }

    if (variant === 'function') {
      return `${base} ${darkMode ? 'bg-gray-700 hover:bg-gray-600 text-gray-200' : 'bg-gray-200 hover:bg-gray-300 text-gray-700'}`;
    }

    if (variant === 'equals') {
      return `${base} ${darkMode ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-md shadow-emerald-500/20' : 'bg-emerald-500 hover:bg-emerald-600 text-white shadow-md shadow-emerald-500/20'}`;
    }

    // number
    return `${base} ${darkMode ? 'bg-gray-800 hover:bg-gray-700 text-white' : 'bg-white hover:bg-gray-50 text-gray-800 shadow-sm'}`;
  };

  return (
    <button
      onClick={onClick}
      className={getButtonStyles()}
      aria-label={label}
    >
      {label}
    </button>
  );
}

export default App;
